This directory exists because the version of NGiNX currently used hard codes the location of the error.log and will exit if the directory does not exist at start time.
